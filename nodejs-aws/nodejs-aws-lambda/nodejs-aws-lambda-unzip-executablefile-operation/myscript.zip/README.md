# Your Script

zip the executable of your choice
